/*
	Function: Generate and append XML structures for pre/post transfer calls in Monitor Definition XML document
*/
self.log("Starting Monitor Build.");
var monitorTemplate = project.getProperty("monitorTemplate");
var newln = project.getProperty("separator");
var preSource = project.getProperty("preSrcC");
var postSource = project.getProperty("postSrcC");
var preDest = project.getProperty("preDestC");
var postDest = project.getProperty("postDestC");

var transferType = project.getProperty("ttype");
var srcDisp = project.getProperty("srcdisp");
var exists = project.getProperty("exists");
var destination = project.getProperty("dd");
var srcResource = project.getProperty("sd");
var templateType = project.getProperty("tt");
var mqaFileSpecPath = project.getProperty("mqaFileSpecPath");
var monitorTemplateObj = XML(monitorTemplate);	

var preSourceCallObj = XML(<preSourceCall>
                <command name="{ant_Name}" retryCount="0" retryWait="0" successRC="0" type="antscript">
                 </command>
              </preSourceCall>);
var postSourceCallObj = XML(<postSourceCall>
                <command name="{ant_Name}" retryCount="0" retryWait="0" successRC="0" type="antscript">
                 </command>
              </postSourceCall>);
var preDestinationCallObj = XML(<preDestinationCall>
                <command name="{ant_Name}" retryCount="0" retryWait="0" successRC="0" type="antscript">
                 </command>
              </preDestinationCall>);
var postDestinationCallObj = XML(<postDestinationCall>
                <command name="{ant_Name}" retryCount="0" retryWait="0" successRC="0" type="antscript">
                 </command>
              </postDestinationCall>);


// set mqaFileSpecPath
if ( mqaFileSpecPath.length() > 0 && (! mqaFileSpecPath.equals("NOOP")) ) {
	var mdObj = XML(<metaData key="mqaFileSpecPath">{mqaFileSpecPath}</metaData>);
	
	monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet.metaData += mdObj;
}

// build item list
if (templateType.toUpperCase() == "FILETODIRECTORY") {
	var items = new Array( ); // Define an array
	items = new String(srcResource).split("~");

	// iterate over that array
	for (i = items.length - 1; i >= 0; i--)
	{
		var item = items[i];
		var itemObj = XML(<item checksumMethod="MD5" mode="binary">
							<source disposition="delete" recursive="false">
								<file>{item}</file>
							</source>
							<destination exist="overwrite" type="directory">
								<file>{destination}</file>
							</destination>
						  </item>);
		
		itemObj.@mode = transferType;
		itemObj.source.@disposition = srcDisp;
		itemObj.destination.@exist = exists;
		
		monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet += itemObj;
	} 
} else if (templateType.toUpperCase() == "FILETOFILE") {
	var items = new Array( ); // Define an array
	items = new String(srcResource).split("~");

	// iterate over that array
	for (i = items.length - 1; i >= 0; i--)
	{
		var item = items[i];
		var itemObj = XML(<item checksumMethod="MD5" mode="binary">
							<source disposition="delete" recursive="false">
								<file>{item}</file>
							</source>
							<destination exist="overwrite" type="file">
								<file>{destination}</file>
							</destination>
						  </item>);
		
		itemObj.@mode = transferType;
		itemObj.source.@disposition = srcDisp;
		itemObj.destination.@exist = exists;
		
		monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet += itemObj;
	}
}

// post destination transfer call
if (postDest != "Z")
{
  var t1 = new String(postDest).split("~");	
  postDestinationCallObj.command.@name = t1[0]; // Adjust the name of the command
  var cmdType = t1[0].search("xml");
  if (cmdType >= 1) 
  {
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("|");
	  postDestinationCallObj.command.appendChild( <property name="{pname}" value="{pvalue}"/>);
	  postDestinationCallObj.command.property[a-1].@name = t2[0]; // Adjust the Property name  
	  postDestinationCallObj.command.property[a-1].@value = t2[1]; // Adjust the Property value
	  }
  }
  else
  {
	postDestinationCallObj.command.@type = "executable"; // Adjust the type
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("~");
	  postDestinationCallObj.command.appendChild(<argument></argument>);
	  postDestinationCallObj.command.argument[a-1] = t2[0]; // Adjust the argument value  
	  }	
  }
 monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet += postDestinationCallObj;
}

// pre destination transfer call
if (preDest != "Z")
{
  var t1 = new String(preDest).split("~");	
  preDestinationCallObj.command.@name = t1[0]; // Adjust the name of the command  
  var cmdType = t1[0].search("xml");
  if (cmdType >= 1) 
  {
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("|");
	  preDestinationCallObj.command.appendChild( <property name="{pname}" value="{pvalue}"/>);
	  preDestinationCallObj.command.property[a-1].@name = t2[0]; // Adjust the Property name  
	  preDestinationCallObj.command.property[a-1].@value = t2[1]; // Adjust the Property value
	  }
  }
  else
  {
	preDestinationCallObj.command.@type = "executable"; // Adjust the type
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("~");
	  preDestinationCallObj.command.appendChild(<argument></argument>);
	  preDestinationCallObj.command.argument[a-1] = t2[0]; // Adjust the argument value  
	  }	
  }
 monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet += preDestinationCallObj;
}

// post source transfer call
if (postSource != "Z")
{
  var t1 = new String(postSource).split("~");	
  postSourceCallObj.command.@name = t1[0]; // Adjust the name of the command
  var cmdType = t1[0].search("xml");
  
  if (cmdType >= 1) 
  {
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("|");
	  postSourceCallObj.command.appendChild( <property name="{pname}" value="{pvalue}"/>);
	  postSourceCallObj.command.property[a-1].@name = t2[0]; // Adjust the Property name  
	  postSourceCallObj.command.property[a-1].@value = t2[1]; // Adjust the Property value
	  }
  } else {
	postSourceCallObj.command.@type = "executable"; // Adjust the type

	for (a = 1; a < t1.length ; a++)
	{ 
		var t2 = new String(t1[a]).split("~");
		postSourceCallObj.command.appendChild(<argument></argument>);
		postSourceCallObj.command.argument[a-1] = t2[0]; // Adjust the argument value  
	}	
  }
  
  monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet += postSourceCallObj;
}

// pre source transfer call
if (preSource != "Z")
{
  var t1 = new String(preSource).split("~");	
  preSourceCallObj.command.@name = t1[0]; // Adjust the name of the command  
  var cmdType = t1[0].search("xml");
  if (cmdType >= 1) 
  {
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("|");
	  preSourceCallObj.command.appendChild( <property name="{pname}" value="{pvalue}"/>);
	  preSourceCallObj.command.property[a-1].@name = t2[0]; // Adjust the Property name  
	  preSourceCallObj.command.property[a-1].@value = t2[1]; // Adjust the Property value
	  }
  }
  else
  {
	preSourceCallObj.command.@type = "executable"; // Adjust the type
	 for (a = 1; a < t1.length ; a++)
	 { 
	  var t2 = new String(t1[a]).split("~");
	  preSourceCallObj.command.appendChild(<argument></argument>);
	  preSourceCallObj.command.argument[a-1] = t2[0]; // Adjust the argument value  
	  }	
  }
 monitorTemplateObj.tasks.task.transfer.request.managedTransfer.transferSet.metaDataSet += preSourceCallObj;
}

 project.setProperty("updatedXML",monitorTemplateObj.toString());
 //self.log("This is the new Obj: " + newln + monitorTemplateObj.toString());